# Solucion Recu
## Ejercicio 1
### IDEA
Voy a tener un array de tamaño MAX_TASKS con elementos del tipo pareja_t, structs q se guardan el id de la pareja, el id de la tarea lider y si es una pareja valida. Este ultimo atributo se setea en true cuando se forme una pareja con la funcion juntarse_con(una tarea), de esta manera las identifico como pareja y les garantizo el acceso a memoria. Como el enunciado dice que la asignacion es a demanda, no necesito mapearles nada aun. Cuando quieran acceder va a saltar un page fault y ahi voy a darles el acceso si corresponde.
Cuando salta el page fault, se llama a page fault handler con parametro virt, que es la direccion virtual q hace saltar el page fault. Chequeo si virt esta dentro del rango 0xC0C00000 hasta 4MB y si la current_task pertenece a una pareja(tiene el attr es pareja valida en true). Si se cumplen estas condiciones, pido una pagina fisica con mmu_next_free_user_page y hago map page a las dos tareas de virt a la misma pagina fisica, a la tarea lider con privilegios de escritura y lectura, y a la otra solo con privilegios de lectura. Despues llamo a zero_page con virt para limpiar la pagina. 

Cuando una tarea abandona la pareja le desmapeo todas las paginas y le cambio el attr es pareja valida a false, por ende si quiere acceder salta el page fault y no se va a cumplir la condicion q current_task pertence a una pareja. Notar que solo le cambio dicho atributo a la tarea abandonadora, esto permite q si una tarea abandona a la tarea lider, esta puede seguir accediendo a la memoria, mientras q la abandonadora ya no.

aclaracion: voy a usar el obtener cr3 que vimos en la clase pre parcial:
```c
uint32_t obtenerCR3(uint16_t selector){
    uint16_t idx = selector >> 3;
    tss_t* tss = gdt[idx].base; //aca en realidad hay que reconstruir la direccion usando ors y las distintas partes de la base pero asumo que asi se entiende
    return tss->cr3;
}
```

### syscall crear pareja
Lo primero que hago es crear la nueva entrada en la IDT para la syscall
```c
IDT_ENTRY3(99) //uso la funcion del tp que me crea una entrada de nivel 3 en la idt
```
Escribo su rutina de atencion:

```asm
_isr99:
pushad
    call crear_pareja

    ; si la tarea actual quedó pausada (líder)
    mov ax, [sched_tasks + current_task * sizeof(sched_entry_t) + offset_estado]
    cmp ax, 0xPAUSED   ; o el valor que uses para PAUSED
    jne .fin           ; si no está pausada, seguimos normalmente

    ; saltamos a la siguiente tarea runnable
    call sched_next_task       ; devuelve selector de la próxima tarea en ax
    mov word [sched_task_selector], ax
    jmp far [sched_task_offset]

.fin:
    popad
    iret

```
Podria tambien tener flag current_task_paused, que se setee a 1 cuando pausamos la tarea actual. Se verifica cmp byte[current_Task_paused], 1 y si son iguales hace el cambio de tarea. En sched next task lo volvemos a setear a 0.

Voy a modificar sched_entry_t y le agrego el "esta_en_pareja" . Ademas me creo un array de tamaño MAX_TASKS que guarda la info de las parejas, con el id de cada tarea accedo a un struct que guarda el id de la pareja y quien el el lider
```c
typedef struct {
  int16_t selector;
  task_state_t state;
  int esta_en_pareja = 0; //todas las tareas arrancan sin pareja. 0 si no esta en pareja, 1 si esta en pareja, 2 si esta en pareja pero no quiere(es lider y esta esperando q su pareja la abandone)
} sched_entry_t;

typedef struct{
    uint8_t id_pareja = -1; //arranco todo en -1
    uint8_t lider = -1;
    bool es_pareja_valida = false;
}pareja_t

pareja_t parejas[MAX_TASKS];
uint8_t current_task = 0;

void crear_pareja(){
    if(sched_tasks[currrent_task].esta_en_pareja == 1){ //si ya esta en pareja no la dejo crear otra
        return;
    }
    //preguntar si cuando se crea la pareja pero todavia no se unio otra tarea se puede decir q la lider esta en pareja o no.
    parejas[current_task].lider = current_task; //seteo la tarea q llamo a crear pareja como la lider
    sched_disable_task(); //la deshabilito, esta funcion pone el estado de la tarea en pausa, cuando otra tarea se una lo pongo en runnable  

}
```
### syscall juntarse con
De la misma manera que con la syscall anterior creo la nueva entrada en la IDT 
```c
IDT_ENTRY3(97) //uso la funcion del tp que me crea una entrada de nivel 3 en la idt
```
Escribo su rutina de atencion:

```asm
_isr97:
pushad

push EDI ;asumo que me pasan por EDI el id de la tarea
call juntarse_con
add esp, 4

popad
iret
```

```c
pareja_t parejas[MAX_TASKS];
uint8_t current_task = 0;

int juntarse_con(uint8_t id_tarea){
    if(sched_tasks[current_task].esta_en_pareja == 1){
        return 1;
    }
    if(esta_buscando_pareja(id_tarea)){
        sched_enable_task(id_tarea); //la vuelvo a activar, pone su estado en runnable
        sched_tasks[current_task].esta_en_pareja = 1;
        sched_tasks[id_tarea].esta_en_pareja = 1;

        parejas[current_task].id_pareja = id_tarea;
        parejas[current_task].lider = id_tarea;
        parejas[current_task].es_pareja_valida = true;

        parejas[id_tarea].id_pareja = current_task;
        parejas[id_tarea].es_pareja_valida = true;
        return 0;
    }
    return 1; //no estaba buscando pareja
}

bool esta_buscando_pareja(uint8_t id_tarea){ 
    return (parejas[id_tarea].lider == id_tarea && parejas[id_tarea].es_pareja_valida == false && sched_tasks[id_tarea].esta_en_pareja == 0) 
}


```



### syscall abandonar pareja
De la misma manera que con la syscall anterior creo la nueva entrada en la IDT 
```c
IDT_ENTRY3(96) //uso la funcion del tp que me crea una entrada de nivel 3 en la idt
```
Escribo su rutina de atencion:

```asm
_isr96:
pushad
    call abandonar_pareja

    ; Si la tarea actual es líder y está pausada, hacemos context switch
    mov ax, [sched_tasks + current_task * sizeof(sched_entry_t) + offset_esta_en_pareja]
    cmp ax, 2        ; 2 significa "no quiere pareja"
    jne .fin         ; si no es líder, seguimos normalmente

    ; Avanzamos a la siguiente tarea runnable
    call sched_next_task        ; devuelve selector en ax
    mov word [sched_task_selector], ax
    jmp far [sched_task_offset] ; salto a la nueva tarea

.fin:
    popad
    iret
```
```c
void abandonar_pareja(){
    if(!es_lider(current_task)){
        uint8_t lider = parejas[current_task].lider;
        sched_tasks[current_task].esta_en_pareja = 0;
        if(sched_tasks[lider].esta_en_pareja == 2){//no quiere estar mas en pareja
            sched_enable_task(lider); //pongo su estado en RUNNABLE de nuevo
            sched_tasks[lider].esta_en_pareja = 0;
            parejas[lider].es_pareja_valida = 0;
            parejas[lider].lider = -1;
            parejas[lider].id_pareja = -1;
            //le desmapeo las paginas al lider
            int cant_paginas = MAX_MEMORY/PAGE_SIZE;
            uint16_t selector = sched_tasks[lider].selector;
            uint32_T CR3_lider = obtenerCR3(selector);
            for(int i = 0; i<cant_paginas; i++){
                vaddr_t virt = 0xC0C00000
                mmu_unmap_page(CR3_lider, virt);
                virt += 0x1000;
        }
        }
        parejas[current_task].lider = -1;
        parejas[current_task].id_pareja = -1;
        parejas[current_task].es_pareja_valida = false;

        parejas[lider].id_pareja = -1;
        //desmapeo las paginas de la tarea abandonadora
        int cant_paginas = MAX_MEMORY/PAGE_SIZE;
        for(int i = 0; i<cant_paginas; i++){
            vaddr_t virt = 0xC0C00000
            mmu_unmap_page(rcr3(), virt);
            virt += 0x1000;
        }
        
    }
    if(es_lider(current_task)){
        sched_tasks[current_task].esta_en_pareja = 2; //marco que no quiere estar en pareja
        sched_disable_task(current_task); //pongo el estado de la tarea en PAUSED, cuando la otra tarea lo abandone retoma
    }
}

bool es_lider(id_tarea){
    return (parejas[id_tarea].lider == id_tarea);
}

```
Ahora modifico el page fault handler para que chequee si el fault fue por acceso a la memoria compartida y si la tarea que accede tiene el acceso permitido, le mapea a las dos tareas la direccion virtual a la misma direccion fisica(a cada una con los permisos correspondientes).
```c
uint32_t MAX_MEMORY = 4MB;

uint8_t current_task = 0;
bool page_fault_handler(vaddr_t virt){
    print("Atendiendo page fault...", 0, 0, C_FG_WHITE | C_BG_BLACK);
    // Chequeemos si el acceso fue dentro del area on-demand
    if(virt >= ON_DEMAND_MEM_START_VIRTUAL && virt <= ON_DEMAND_MEM_END_VIRTUAL){ // En caso de que si, mapear la pagina
        uint32_t cr3 = rcr3();
        mmu_map_page(cr3, virt, ON_DEMAND_MEM_START_VIRTUAL, MMU_P | MMU_W | MMU_U); // RW usuario
        return true;
    }
   //chequeo si el acceso fue dentro de los 4MB de la mem compartida
    if(virt >= 0xC0C00000 && virt <= 0xC0C00000 + MAX_MEMORY && tiene_acceso(current_task)){
        uint32_t cr3 = rcr3();
        paddr_t page = next_free_user_page(); 
        uint8_t id_pareja = parejas[current_task].id_pareja;
        uint8_t selector_pareja = sched_tasks[id_pareja].selector;
        uint32_t cr3Pareja = obtenerCR3(selector_pareja);
        if(es_lider(current_task)){
            mmu_map_page(cr3, virt, page, MMU_P | MMU_W | MMU_U);
            mmu_map_page(cr3Pareja, virt, page, MMU_P | MMU_U); //no le doy permisos de escritura a la q no es lider
            zero_page(virt);
            return true;
        }else{//la otra es lider
            mmu_map_page(cr3, virt, page, MMU_P | MMU_U);
            mmu_map_page(cr3Pareja, virt, page, MMU_P | MMU_W | MMU_U); //Esta es la lider, le doy permisos de escritura
            zero_page(virt);
            return true;
        }
    }
    
    return false;
}

bool tiene_acceso(uint8_t id_tarea){
    return parejas[id_tarea].es_pareja_valida
}
```
## Ejercicio 2
Podria modificar la estructura pareja_t para q se guarde la cantidad de paginas usada por la pareja, esto se actualizaria en el page fault handler, cuando le mapea una pagina aumenta el contador. El problema es q tengo la info duplicada, podria agregar un atributo "sumar" que me indique a la hora de recorrer las parejas si tengo q tener en cuenta ese elemento al hacer la suma o ya sume la cantidad de memoria usada por su pareja. En el ejercicio 1 lo unico q tendria q hacer es agregar estos dos atributos inicializados en 1 y 0 respectivamente(como muestro abajo) y solo se modifica el page fault handler como muestro mas abajo, lo demas queda igual.
Me quedaria algo asi:
```c
typedef struct{
    uint8_t id_pareja = -1; //arranco todo en -1
    uint8_t lider = -1;
    bool es_pareja_valida = false;
    int sumar = 1;
    uint32_t cant_paginas_usadas = 0; 
}pareja_t

```
Lo unico q tendria q hacer es agregar al page fault handler son estas dos lineas:
```c
parejas[current_task].cant_paginas_usadas++;
parejas[id_pareja].cant_paginas_usadas++;
```
quedaria asi: 
```c
bool page_fault_handler(vaddr_t virt){
    print("Atendiendo page fault...", 0, 0, C_FG_WHITE | C_BG_BLACK);
    // Chequeemos si el acceso fue dentro del area on-demand
    if(virt >= ON_DEMAND_MEM_START_VIRTUAL && virt <= ON_DEMAND_MEM_END_VIRTUAL){ // En caso de que si, mapear la pagina
        uint32_t cr3 = rcr3();
        mmu_map_page(cr3, virt, ON_DEMAND_MEM_START_VIRTUAL, MMU_P | MMU_W | MMU_U); // RW usuario
        return true;
    }
   //chequeo si el acceso fue dentro de los 4MB de la mem compartida
    if(virt >= 0xC0C00000 && virt <= 0xC0C00000 + MAX_MEMORY && tiene_acceso(current_task)){
        uint32_t cr3 = rcr3();
        paddr_t page = next_free_user_page(); 
        uint8_t id_pareja = parejas[current_task].id_pareja;
        uint8_t selector_pareja = sched_tasks[id_pareja].selector;
        uint32_t cr3Pareja = obtenerCR3(selector_pareja);
        if(es_lider(current_task)){
            mmu_map_page(cr3, virt, page, MMU_P | MMU_W | MMU_U);
            mmu_map_page(cr3Pareja, virt, page, MMU_P | MMU_U); //no le doy permisos de escritura a la q no es lider
            zero_page(virt);
            return true;
        }else{//la otra es lider
            mmu_map_page(cr3, virt, page, MMU_P | MMU_U);
            mmu_map_page(cr3Pareja, virt, page, MMU_P | MMU_W | MMU_U); //Esta es la lider, le doy permisos de escritura
            zero_page(virt);
            return true;
        }
        parejas[current_task].cant_paginas_usadas++;
        parejas[id_pareja].cant_paginas_usadas++;
    }
    
    return false;
}
```
```c
uint32_t uso_de_memoria_de_las_parejas(){
    uint32_t res = 0;
    for(int i=0; i<MAX_TASKS; i++){
        if(parejas[i].sumar == 1){ //chequeo poder sumar
            if(parejas[i].es_pareja_valida && !es_pareja_vacia(parejas[i])){
                res += parejas[i].cant_paginas_usada;
                uint8_t pareja = parejas[i].id_pareja;
                parejas[pareja].sumar = 0; //me aseguro de no sumar a su pareja
            }
            if(parejas[i].es_pareja_valida && es_pareja_vacia(parejas[i])){ //caso pareja vacia
                res += parejas[i].cant_paginas_usada; 
            }
        }
    //si sumar esta en 0, ya sume su memoria, paso al siguiente elem
        
    }
    res = res/250; //1MB son 1000KB, que son 250 paginas, divido por 250 para obtener la mem usada en MB.
    return res;
}
```