#include "task_lib.h"

#define WIDTH TASK_VIEWPORT_WIDTH
#define HEIGHT TASK_VIEWPORT_HEIGHT

#define SHARED_SCORE_BASE_VADDR (PAGE_ON_DEMAND_BASE_VADDR + 0xF00)
#define CANT_PONGS 3
//definidas por nosotros
#define CANT_DE_JUGADORES_POR_PARTIDO 2

void imprimirPuntosEnPantalla(screen pantalla){
	task_draw_box(pantalla, 0, 0, WIDTH, HEIGHT, ' ', C_BG_BLACK);
    int y = 2;
    for(int i =0 ; i < CANT_PONGS;i++){ //avanzamos por partido(tarea)
	   uint32_t* direccionDePuntajesCompartidos = 
            (uint32_t*)(SHARED_SCORE_BASE_VADDR + i * sizeof(uint32_t) * 2);  
	   uint32_t puntosJugador1 = direccionDePuntajesCompartidos[0];
	   uint32_t puntosJugador2 = direccionDePuntajesCompartidos[1];

	   task_print_dec(pantalla, i, 2, 2, y, C_FG_WHITE);
       task_print(pantalla, "  Jugador 1 ", 5, y, C_FG_CYAN);
       task_print_dec(pantalla, puntosJugador1, 2, 17, y, C_FG_CYAN);
       task_print(pantalla, "   Jugador 2 ", 20, y, C_FG_MAGENTA);
       task_print_dec(pantalla, puntosJugador2, 2, 34, y, C_FG_MAGENTA);
	  
	   y+=2;
	}
}

void task(void) {
	screen pantalla;
	// ¿Una tarea debe terminar en nuestro sistema? NO,eso lo veria el scheduler para liberarlo
	while (true)
	{
	    imprimirPuntosEnPantalla(pantalla);
		syscall_draw(pantalla);
		task_sleep(100);//esto es la cant de milisgs que vamos a actualizr pantalla
	}
}
