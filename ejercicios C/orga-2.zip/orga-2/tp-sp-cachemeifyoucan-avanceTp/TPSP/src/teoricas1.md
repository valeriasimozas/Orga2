link a las tablas: https://docs.google.com/spreadsheets/u/0/d/1sVL2sb553Kgx_nogDWQRMuym6I2ODH6q9LTkxHqcKOM/htmlview
(tiene pedido de permiso, no sabemos como sacarle pero estamos atentos para cuadno quieran verlo :).
1) Explorando el manual Intel Volumen 3: System Programming. Sección 2.2 Modes of Operation. ¿A qué nos referimos con modo real y con modo protegido en un procesador Intel? ¿Qué particularidades tiene cada modo?
Modo real: es el modo de operacion del procesador intel 8086,no cuenta con niveles de privilegio por lo que se puede ejecutar todas las instrucciones, memoria disponible aprox. 1 Mb.
Modo protegido: es el modo nativo del procesador, tiene 4 niveles de proteccion y cuenta con instrucciones basadas en el nivel de privilegio, memoria disponible aprox. 4Gb

2) Comenten en su equipo, ¿Por qué debemos hacer el pasaje de modo real a modo protegido? ¿No podríamos simplemente tener un sistema operativo en modo real? ¿Qué desventajas tendría?
Para empezar, un sistema operativo sin niveles de proteccion permitiria hacer cualquier instruccion, lo cual puede llevar a consecuencias catastroficas si quien las usa no es cuidadoso. Ademas, el modo real es limitado en su memoria y esta presente mas por compatibilidad que por otra cosa, teniendo en cuenta que ademas las direcciones de memoria son menores (20 bits) y las interrupciones no tienen niveles de prioridad lo cual no es optimo.

3) Busquen el manual volumen 3 de Intel en la sección 3.4.5 Segment Descriptors. ¿Qué es la GDT? ¿Cómo es el formato de un descriptor de segmento, bit a bit? Expliquen brevemente para qué sirven los campos Limit, Base, G, P, DPL, S.
La GDT (Global Description Table) es una estructura de datos que provee al procesador la informacion de donde empieza y termina cada segmento,suele empezar con un segmento nulo y los valores de esta tabla son segment descriptors.
Los segment descriptors son c/u de 8 bytes: los primeros 16(0-15) son parte del segment limit, los siguientes 16 (16-31) son parte del base address, los proximos 4 bytes van del siguiente modo: 8 bytes para base address(0-7), 3 bits para el tipo (8-11), 1 bit para el descriptor de tipo (S), 2 bits para el dpl (descriptor de nivel de privilegio), 1 bit para indicar segmento presente(P), 3 bits mas para segment limit (16-19), 1 bit para avl, otro bit para L , otro bit para d/b, otro bit para G, y los ultimos 8 bits para base  address (24-31). 
Limit: indica el tamaño del segmento en un valor de 20 bits, se interpreta de dos formas dependiendo de G: si G esta apagada el tamaño de segmento puede variar entre un byte y un MByte, mientras que si esta prendida los segmentos pueden variar entre  4 KBytes a 4 GBytes.
Base: valor de 32bits que define la direccion del byte 0 del segmento dentro de un espacio de direcciones de 4 GBytes.
G: como explicamos en limit, define la escala en que se interpreta los tamaños de segmento.
P: si esta encendido indica que el segmento esta presente en la direccion de memoria asociada, si esta bajo entonces se lanza una segment no present fault.
DPL: indica el nivel de prioridad de un segmento (0: kernel , 3: usuario, 1y2 en desuso)
S: si esta en baja es segmento para sistema, en cambio si esta en alta es para codigo/data. 

4) La tabla de la sección 3.4.5.1 Code- and Data-Segment Descriptor Types del volumen 3 del manual del Intel nos permite completar el Type, los bits 11, 10, 9, 8. ¿Qué combinación de bits tendríamos que usar si queremos especificar un segmento para ejecución y lectura de código?
Bit 11: 1
Bit 10: 0
Bit 9: 1
Bit 8: 0

6) En el archivo gdt.h observen las estructuras: struct gdt_descriptor_t y el struct gdt_entry_t. ¿Qué creen que contiene la variable extern gdt_entry_t gdt; y extern gdt_descriptor_t GDT_DESC;?
Estas variables contienen las estructuras que definimos externamente (C o ASM), por lo que referencian en este caso:
extern gdt_entry_t gdt: array estatico que tiene los descriptores de segmento que definimos en gdt.c
extern gdt_descriptor_t GDT_DESC: este struct es un descriptor del tamaño de la gdt junto con su direccion de memoria.

10) Busquen qué hace la instrucción LGDT en el Volumen 2 del manual de Intel. Expliquen con sus palabras para qué sirve esta instrucción. En el código, ¿qué estructura indica donde está almacenada la dirección desde la cual se carga la GDT y su tamaño? ¿dónde se inicializa en el código?
La instruccion lgdt carga en el registro GDTR la direccion de memoria y el limite de la gdt que definimos. 
La estructura es GDT_DESC la cual tiene en su primer posicion el tamaño de la gdt y en la segunda la direccion de memoria. Esta estara definida en el gdt.c y declarada en el gdt.h por lo tanto el linker debera resolver esta referencia.

13) Investiguen en el manual de Intel sección 2.5 Control Registers, el registro CR0. ¿Deberíamos modificarlo para pasar a modo protegido?
Debemos modificarlo ya que hay que prender el bit 0 de dicho registro (PE=Protection Enable) para pasar a modo protegido.

15) Notemos que a continuación debe hacerse un jump far para posicionarse en el código de modo protegido. Miren el volumen 2 de Intel para ver los distintos tipos de JMPs disponibles y piensen cuál sería el formato adecuado. ¿Qué usarían como selector de segmento? 
El formato adecuado seria JMP ptr16:32 (opcode EA cp) ya que es un jump far que recibe 16 bits para CS y 32 bits para la dirección en modo protegido. Como selector de segmento usamos el selector del descriptor de código nivel 0, que en este caso es 8 ya que esta luego del descriptor nulo.

21) Declaren un segmento adicional que describa el área de la pantalla en memoria que pueda ser utilizado sólo por el kernel. ¿Qué tamaño deberá tener considerando lo descrito en el párrafo anterior? Si el buffer de la pantalla comienza en 0x000B8000, piensen cuál debería ser la base y el límite. 
El tamaño es 40 * 80 * 2 bytes porque hay 40 filas y 80 columnas donde en cada posicion hay 2 bytes. La base es 0x000B8000 y el limite (40 * 80 * 2) - 1 bytes. 

22) Observen el método screen_draw_box en screen.c y la estructura ca en screen.h . ¿Qué creen que hace el método screen_draw_box? ¿Cómo hace para acceder a la pantalla? ¿Qué estructura usa para representar cada carácter de la pantalla y cuanto ocupa en memoria?
El metodo screen_draw_box accede a la direccion del buffer definido en VIDEO (0x000B8000) y luego lo recorre y modifica el struct en c/ posicion del arreglo poniendo el atributo y caracter pasados por parametro. Cada caracter se representa con el struct ca y ocupa 2 bytes (1 byte para char y otro para color).

24) Pasar a modo protegido: desactivar interrupciones, armar la gdt y cargarla en el registro gdtr, activar el bit de pe, hacer un far jump (en este caso al ds_0), guardar los segmentos en los registros, y armar el stack.
