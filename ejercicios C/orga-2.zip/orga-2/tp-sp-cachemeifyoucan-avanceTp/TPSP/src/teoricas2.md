1)
a)
- Los campos offset toman los valores desde 0 a 15 inferiores y 16 a 31 superiores. Refieren a la ubicación de la interrupción.
- Los bits 16 a 31 inferiores refieren al selector de segmento.
- El bit 15 refiere al flag present, que determina si esta presente en memoria.
- 13 y 14, análogamente al gdt, refieren al decriptor privilege level, es decir nuestro nivel de privilegios, que puede variar desde 0 a 3.
- El bit 11, D, refiere al tamaño de la gate de la interrupción, si 32 o 16 bits.

b) Utilizamos como segsel GDT_CODE_0_SEL. CODE debido a que buscamos definir el comportamiento de nuestras interrupciones, y 0 ya que las interrupciones necesitan ser manejadas por el kernel, la idea es que no cualquier programa las active.

Además como queremos que gate size sea de 32 bits, seteamos el bit 11, D, a 1.

2) Utilizamos la funcion definida IDT_ENTRY_0, que nos crea una entrada de la IDT con nivel de privilegios 0. Buscamos que sea nivel 0 pues queremos que el sistema operativo sea quien se encarge de manejar el reloj y el teclado, no asi los programas. En el caso de que un programa se cuelge, si el programa tiene el teclado restringido, puede evitar el cierre. Lo mismo con el reloj, si un programa se cuelga, sin el reloj no sabremos si se cuelga, y por ende no podremos cerrarlo.

3) Para estas rutinas, el prólogo consta de:
- pushad (para guardar los registros de propósito general)
- call pic_finish1 (para decirle al PIC que vamos a atender la interrupción)

y el epílogo consta de:
- popad (para restaurar los registros almacenados con pushad)
- iret

Utilizamos iret y no ret pues este último no restaura flags ni el code segment.
