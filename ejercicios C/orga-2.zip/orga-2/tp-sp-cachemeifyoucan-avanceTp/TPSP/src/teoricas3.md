Primera parte

a) Tenemos  dosniveles de privilegio, kernel y usuario.

b) Empezamos por 20 bits mas altos de CR3 y y asi obtenemos el page directory(hacemos un and con 0xFFFFF000),ahora calculamos el indice dentro de la page directory(hacemos un shift a derecha de 22bits y una mascara con 0x3FF para quedarnos con los 10 bits altos de la direccion virtual).Ahora podemos indexar el directorio en el indice obtenido teniendo asi la page table y aplicamos una mascara 0xFFFFF000 para quedarnos con los 20 bits mas altos, que sera la direccion de la page table.
Ahora para obtener el indice de la page table shifteamos la direcion virtual 12 bits a derecha y aplicamos mascara 0x3FF para quedarnos con los 10 bits del medio dela direccion virtual.(*)
Ahora indexamos la page table en el indice obtenido en (*) y aplicamos la mascara 0xFFFFF000 con un and y obtenemos direccion de pagina.
Ahora hacemos un and entre la direccion virtual con la mascara oxFFF para quedarnos con los 12 bits del offset, y esto sumado a la direccion de la pagina nos da la direccion fisica buscada.
c) 
    D:indica si se escribio a memoria controlada por esta page table .
    A:indica si se accedio a memoria controlada por esta page table entry.
    PCD:deshabilita cachear los datos de pagina asociada. 
    PWT:deshabilita hacer writeback al escribir en la pagina asociada.
    U/S:determina si un proceso en modo usuario puedeacceder a la memoria controlada por esta page table entry.
    R/W:determina si un proceso puede escribir a la memoria controlada por esta page table entry.
    P:indica que esta traduccion es valida. Siempre debe estar en 1.
d) Si difieren entre supervisor y usuario el nivel de privilegio resultante es supervisor.Siempre que el nivel de priviegio resultante es de supervisor entonces el modo de acceso sera read/write.
Si ambos son usuarios y ambos tienen el mismo modo de acceso este sera el resultante, en cambio si difieren en que modo de acceso usar por defecto se usara read-only.
e) Tres paginas: dos para memeoria de la tarea mas una para el stack de la tarea.
Dos paginas: una para el page table y una para el page directory de la tarea.
En total serian 5 paginas por cada tarea.

g) El TLB es una cache del procesador que guarda traducciones recientes de direcciones virtuales a fisicas. Cuando se requiere realizar una traduccion, primero se chequea en la TLB si ya se hizo y se accede a la memoria fisica, y sino se realiza todo el proceso de traduccion mencionado antes (y se guarda en la TLB el resultado).

Es necesario purgarla cuando modificamos las estructuras de paginacion porque si justo lo que modificamos esta guardado en la TLB, cuando se va a buscar la traduccion se puede acceder a la direccion vieja que ahora no es correcta. Si la purgamos despues de modificar, la proxima vez que se quiera la traduccion, la TLB guardará los datos a partir de las estructuras actualizadas.

Atributos: 
Virtual Page Number: página virtual que se traduce.
Physical Page Number: dirección física de la página.
Los derechos de acceso de las entradas de las estructuras:
-AND logico de R/W
-AND logico de U/S
Atributos de una entrada de la estructura de paginación que identifica el marco de página final para el número de página:
—Dirty.
—Tipo de memoria

Cuando se desaloja entrada de la TLB no se modifica la tabla original, simplemente la proxima vez que se acceda a la direccion virtual cuya traduccion se elimino, va a ser necesario realizar todo el proceso de traduccion nuevamente y se guardara otra vez en la TLB

Tercera parte: 
b) Es necesario mapear las paginas de destino y fuente porque no podemos trabajar con direcciones fisicas directamente. Hay que utilizar direcciones virtuales que la MMU traduce a fisicas. SRC_VIRT_PAGE Y DST_VIRT_PAGE actuan como direcciones virtuales temporales a las que se mapean src_addr y dst_addr respectivamente. Se accede a estas ultimas a traves de las virtuales para hacer la copia requerida.
Las desmapeamos luego porque solo las queremos usar como intermediarias para realizar la copia, es un mapeo temporal con ese proposito. Luego se libera para que se puedan mapear otras direcciones fisicas a ellas. Se usa rcr3() porque da valor actual del registro cr3 en donde se encuentra la direccion fisica del page directory.