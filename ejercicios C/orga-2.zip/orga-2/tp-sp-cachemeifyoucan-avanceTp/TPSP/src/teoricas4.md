1) Si queremos definir un sistema que utilice sólo dos tareas, ¿Qué nuevas estructuras, cantidad de nuevas entradas en las estructuras ya definidas, y registros tenemos que configurar?¿Qué formato tienen? ¿Dónde se encuentran almacenadas?

Las tareas necesitan c/u su propia TSS. Dicha TSS tiene guardados los registros de proposito general, los registros de segmento de la tarea y de la pila nivel 0, flags, eip(apuntando a la direccion virtual del comienzo del codigo) y cr3, el cual contendra la direccion del page directory de la tarea.

Ademas, es necesario crear 2 entradas nuevas en la GDT para almacenar los descriptores de las TSS de las tareas.

Cada tarea tiene su propio page directory(ubicado en pagina del kernel), asi que tendremos 1 pagina para cada page directory. Luego, cada tarea puede utilizar hasta 8kb de codigo, lo cual entra en 2 paginas . Tambien tenemos que tener una pagina para la pila de codigo nivel 3 y otra para la pila nivel 0.

2) ¿A qué llamamos cambio de contexto? ¿Cuándo se produce? ¿Qué efecto tiene sobre los registros del procesador? Expliquen en sus palabras que almacena el registro TR y cómo obtiene la información necesaria para ejecutar una tarea después de un cambio de contexto.

Cambio de contexto es cuando se suspende la ejecucion de una tarea y se pasa a ejecutar otra. La administracion de las ejecuciones de las tareas la lleva a cabo el scheduler. Los registros apuntan al estado de la nueva tarea. 

El registro TR almacena el selector de segmento de la TSS actual. El selector tiene en los 12 bits altos el indice de la entrada de la GDT que corresponde al descriptor de la TSS. A partir de la base + limite del descriptor, ubica la TSS y puede acceder al contexto de la tarea a ejecutar

3) Al momento de realizar un cambio de contexto el procesador va almacenar el estado actual de acuerdo al selector indicado en el registro TR y ha de restaurar aquel almacenado en la TSS cuyo selector se asigna en el jmp far. ¿Qué consideraciones deberíamos tener para poder realizar el primer cambio de contexto? ¿Y cuáles cuando no tenemos tareas que ejecutar o se encuentran todas suspendidas?

Para el primer cambio de contexto, como no tenemos tarea activa todavia TR no apunta a ninguna TSS. Tenemos que tener armada la TSS de la tarea inicial y debemos cargar su selector en TR. Como no hay contexto anterior, con eso basta para la ejecucion de la tarea inicial.
Luego, si no tenemos tareas o estan suspendidas todas, debemos tener tarea idle con TSS inicializada y TR debe tener cargado su selector. Esta tarea no hace nada relevante, solo está para que haya siempre una tarea ejecutable

4) ¿Qué hace el scheduler de un Sistema Operativo? ¿A qué nos referimos con que usa una política?
El scheduler administra la ejecucion de las tareas. La política se refiere al criterio que utiliza el scheduler para decidir cual es la proxima tarea a ejecutar.

5) En un sistema de una única CPU, ¿cómo se hace para que los programas parezcan ejecutarse en simultáneo?
El sistema operativo va alternando entre los programas muy rápido. Para eso el scheduler asigna intervalos de tiempo pequeños a cada tarea y cuando se cumple ese tiempo se realiza un cambio de contexto. Como estos cambios suceden muchas veces por segundo, parece que todos los programas se ejecutan simultáneamente.

9) ¿Por qué hace falta tener definida la pila de nivel 0 en la tss?
Hace falta tener definida la pila de nivel 0 en la TSS porque cuando una tarea de usuario pasa al modo kernel (por una interrupción o excepción) el procesador cambia automáticamente a esa pila. Esto se hace para que el código del kernel se ejecute en una zona de memoria segura y con privilegios de nivel 0, en lugar de usar la pila de usuario que pertenece a nivel 3.

11) 
a. Expliquen con sus palabras que se estaría ejecutando en cada tic del reloj línea por línea
pushad: se guardan los registros generales
call pic_finish1: indica al PIC que se atendio la interrupcion
call sched_next_task: obtenemos en ax el selector de proxima tarea a ejecutar de acuerdo al scheduler
str cx: se lee registro TR y se guarda en cx (guardamos el selector de la tarea actual)
cmp ax, cx
je .fin : si estamos tratando con la misma tarea, se salta a fin(no hay cambio de tarea)
mov word[sched_task_selector], ax: si es otra tarea, ubica su selector en parte de memoria corresp al selector
jmp far [sched_task_offset] : hace jump far al selector de la tarea a ejecutar. Se produce cambio de contexto
.fin:
popad : se restauran los registros
iret: se realiza el retorno restaurando eip

b. En la línea que dice jmp far [sched_task_offset] ¿De que tamaño es el dato que estaría leyendo desde la memoria? ¿Qué indica cada uno de estos valores? ¿Tiene algún efecto el offset elegido?
Como se definio con dd, es de 4 bytes. El offset no tiene efecto, ya que solo importa el selector de la TSS para saber de que tarea cargar los registros. Se toma el EIP dentro de la TSS y se empieza a ejecutar desde ahi.

c. ¿A dónde regresa la ejecución (eip) de una tarea cuando vuelve a ser puesta en ejecución?
El eip retoma exactamente desde donde se habia detenido la ultima vez, o sea desde donde quedo antes del ultimo cambio de contexto.

14) a. ¿Qué está haciendo la función tss_gdt_entry_for_task?

Lo que hace la funcion es crear una entrada para la gdt que sea un descriptor de segmento la tss que creamos para la tarea. Alli se guarda la direccion base donde se encuentra la tss en memoria, el limite y otros atributos necesarios. Devuelve dicho descriptor para cargarlo en la gdt.

b. ¿Por qué motivo se realiza el desplazamiento a izquierda de gdt_id al pasarlo como parámetro de sched_add_task?

Porque la funcion sched_add_task recibe el selector de segmento de la GDT de la tarea. La forma del selector es: 12 bits altos con el indice de la gdt, 3 bits bajos de table indicator y requested privilege level. Como estos ultimos deben ser 0, basta con shiftear a la izquierda el indice de la gdt (gdt_id) para que quede en los 12 bits altos convirtiendose en un selector valido.

15) a. ¿Qué mecanismos usan para comunicarse con el kernel?
Utilizan syscalls como por ejemplo syscall_draw que le dice al kernel que dibuje la pantalla con los datos creados y task_sleep que le dice al kernel por cuantos segundos se suspende la tarea.
Luego esta la estructura ENVIROMENT que tiene datos que la tarea puede consultar como los ticks del reloj del sistema, task_id que es el id de la tarea ejecutandose y datos del estado del teclado.

b. ¿Por qué creen que no hay uso de variables globales? ¿Qué pasaría si una tarea intentase escribir en su .data con nuestro sistema?
No se usan variables globales para que las tareas puedan mantener sus contextos independientes y que ninguna acceda o modifique los datos de otra.
En nuestro sistema no mapeamos memoria para el .data de tareas (mmu_init_task_dir no mapea ninguna direccion para ello) por lo tanto si intentamos escribir en el .data de la tarea se deberia generar un pagefault ya que no esta inicializada esa parte de memoria debidamente.Mas aun como no tenemos esta zona de memoria disponible, cualquier intento de leer varias globales o modificarlas llevaria a un page fault, obligando a las tareas a ejecutarse unicamente con los datos de su contexto y asi preservando las variables globales de ser modificadas por las tareas(al menos en esta version de nuestro so).


16) a. ¿Por qué la tarea termina en un loop infinito?
Porque no se esta usando un scheduler. El loop evita que el procesador ejecute basura luego de la tarea termina, de modo que se mantiene en un estado seguro. 
b. ¿Qué podríamos hacer para que esto no sea necesario?
Tener un scheduler que controle el flujo de ejecucion de las tareas, decidiendo cual ejecutar y en que momento suspender

18) ¿Por qué se definen 2 "tipos" de tareas? ¿Como harían para ejecutar una tarea distinta?
Hay 2 tipos de tarea porque la idea es ejecutar 2 programas distintos, donde cada uno tiene su propio codigo y comportamiento. Se debe poder crear pd y tss para cada uno y ademas poder cargarlos en el scheduler.
Para ejecutar una distinta hay que obtener el .tsk correspondiente, agregarla a la lista de tareas en el makefile y copiarla en la imagen de las tareas.
En tasks.c hay que agregar un nuevo tipo al enum (TASK_C por ejemplo), mapearla en task_code_start a la direccion fisica de su codigo y luego añadirla a task_init para que se inicialice su tss, entrada correspondiente en la gdt y se añada a la lista de ejecucion del scheduler.

19) Mirando la tarea Pong, ¿En que posición de memoria escribe esta tarea el puntaje que queremos imprimir? ¿Cómo funciona el mecanismo propuesto para compartir datos entre tareas?
Escribe el puntaje en SHARED_SCORE_BASE_VADDR + task_id*8, donde el 8 viene de que se registran 2 enteros de 4 bytes (uno por jugador). 
Hay una direccion base de memoria virtual compartida (SHARED_SCORE_BASE_VADDR) y cada tarea tiene su task_id al que puede acceder mediante ENVIROMENT, que ayuda a determinar que bloque de memoria virtual le corresponde.
De este modo cada tarea puede escribir sus datos en su bloque correspondiente de la memoria virtual compartida.